
/*
NOMBRE Y APELLIDOS: MARCO CALVO JIMÉNEZ
DNI: 54190798S
GRUPO DE PRÁCTICAS: Lunes
*/

#include <iostream>
#include <cstring>
using namespace std;

int longitudCad(const char cs[]){
	int longitud=0;
	
	for (int i=0; cs[i]!='\0'; i++){
		longitud++;
	}
	return longitud;
}

bool comienzaPalabra(const char cs[], int longitud, int pos){
	if (pos>0 && pos<longitud){
		return (cs[pos-1]==' ' && cs[pos]!=' ');
	} else if (pos==0){
		return (cs[pos]!=' ');
	} else if (pos==longitud){
		return false;
	}
}

bool terminaPalabra(const char cs[], int longitud, int pos){
	if (pos>0 && pos<longitud){
		return (cs[pos]!=' ' && cs[pos+1]==' ');
	} else if (pos==0){
		return false;
	} else if (pos==longitud){
		return (cs[pos-1]!=' ' && cs[pos]==' ');
	}
}

void descifra(const char cs[], char rta[]){
	int longitud=longitudCad(cs);
	int contador=0;
	int segurata=0;
	
	for (int i=0; i<longitud; i++){
		segurata=0;
		if (comienzaPalabra(cs,longitud,i)){
			rta[contador]=cs[i];
			contador++;
			segurata++;
		}
		
		if (segurata!=1){
			if (terminaPalabra(cs,longitud,i)){
				rta[contador]=cs[i];
				contador++;
			}
		}
	}
	rta[contador]='\0';
}
