
/*
NOMBRE Y APELLIDOS: MARCO CALVO JIMÉNEZ
DNI: 54190798S
GRUPO DE PRÁCTICAS: Lunes
*/

#include <iostream>
#include "descifra.h"
#include <cstring>
using namespace std;

void lee_linea(char c[], int tam) {
    do {
        cin.getline(c, tam);
    } while (c[0] == '\0');
}

void prettyPrint(const char c[]) {
    int i = 0;
    while (c[i] != '\0') {
        if (c[i] == ' ')
            cout << '_';
        else
            cout << c[i];
        i++;
    }
}

const int MAX_SIZE = 1000;

int main() {

    char frase[MAX_SIZE];
    char codigo[MAX_SIZE];
    int nPals = 0;
    int tam;

    cin >> nPals;
    cout << "Cadenas a procesar: " << nPals << endl;

    for (int i = 0; i < nPals; i++) {
        cout << endl;
        lee_linea(frase, MAX_SIZE);
        tam = longitudCad(frase);
        prettyPrint(frase);
        cout << " tiene " << tam << " caracteres" << endl;
        descifra(frase, codigo);
        cout << "Codigo -> " << codigo << endl;
    }

    return (0);
}
