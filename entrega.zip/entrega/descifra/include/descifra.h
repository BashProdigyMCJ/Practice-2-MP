#ifndef DESCIFRA_H
#define DESCIFRA_H

int longitudCad(const char cs[]);
bool comienzaPalabra(const char cs[], int longitud, int pos);
bool terminaPalabra(const char cs[], int longitud, int pos);
void descifra(const char cs[], char rta[]);

#endif
