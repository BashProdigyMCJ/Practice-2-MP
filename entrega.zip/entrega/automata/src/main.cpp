
/*
NOMBRE Y APELLIDOS: MARCO CALVO JIMÉNEZ
DNI: 54190798S
GRUPO DE PRÁCTICAS: Lunes
*/

#define BLANCO "\33[30;47m" // fondo blanco
#define NEGRO "\33[30;40m" // fondo negro
#define ROJO "\33[30;41m" // fondo rojo
#define VERDE "\33[30;42m" // fondo verde
#define AZUL "\33[30;44m" // fondo azul
#define RESET "\033[m"

#include <iostream>
#include <cmath>
#include "automata.h"
using namespace std;

int main(){
	
	const int TAM=100;
	bool v[TAM];
	int regla;
	int contador=0;
	int TMAX;
	bool reglas[8];

	for (int i=0; i<TAM; i++){
		v[i]=true;
	}
	v[TAM/2]=false;
	
	cout << "Introduce el numero: ";
	cin >> regla;
	setReglas(reglas,regla);
	
	cout << "Introduce las iteraciones maximas: ";
	cin >> TMAX;
	
	while (contador != TMAX){
    mostrar(v, TAM);
    actualizar(v, reglas, TAM);
    contador++;
	}
	
}
