
/*
NOMBRE Y APELLIDOS: MARCO CALVO JIMÉNEZ
DNI: 54190798S
GRUPO DE PRÁCTICAS: Lunes
*/

#define BLANCO "\33[30;47m" // fondo blanco
#define NEGRO "\33[30;40m" // fondo negro
#define ROJO "\33[30;41m" // fondo rojo
#define VERDE "\33[30;42m" // fondo verde
#define AZUL "\33[30;44m" // fondo azul
#define RESET "\033[m"

#include <iostream>
#include <cmath>
using namespace std;

void setReglas(bool v[], int numero){
	int iteraciones=0;
	int digito;
	int contador_regresivo=7;
			
	while (iteraciones<8){
		digito=numero%2;
		numero/=2;
		
		if (digito==1){
			v[contador_regresivo]=false;
		} else {
			v[contador_regresivo]=true;
		}
		
		contador_regresivo--;
		iteraciones++;
	}
}

void mostrar(const bool state[], int tam){
 for(int i = 0; i < tam; i++){
   if (state[i])
     cout << BLANCO << " " << RESET;
   else
     cout << NEGRO << " " << RESET;
  }
 cout << endl;
}

int binarioDecimal(bool n1, bool n2, bool n3){
	int suma=0;
	
	if(n1){
		suma+=4;
	}
	if(n2){
		suma+=2;
	}
	if(n3){
		suma+=1;
	}
	return suma;
}

void actualizar(bool v1[], const bool reglas[], const int TAM){
	bool v2[TAM];

	for (int i=0; i<TAM; i++){
		
		if (i==0){
			int n=binarioDecimal(v1[TAM-1], v1[0], v1[1]);
			v2[0]=reglas[n];
			
		} else if (i>0 && i<TAM-1){
			int n=binarioDecimal(v1[i-1], v1[i], v1[i+1]);
			v2[i]=reglas[n];
			
		} else if (i==TAM-1){
			int n=binarioDecimal(v1[TAM-2], v1[TAM-1], v1[0]);
			v2[TAM-1]=reglas[n];
		}
	}
	
	for (int i=0; i<TAM; i++){
		v1[i]=v2[i];
	}
}
