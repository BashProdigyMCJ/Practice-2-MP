#ifndef AUTOMATA_H
#define AUTOMATA_H

void setReglas(bool v[], int numero);
void mostrar(const bool state[], int tam);
int binarioDecimal(bool n1, bool n2, bool n3);
void actualizar(bool v1[], const bool reglas[], const int TAM);

#endif
